/*
	TUIO Pure Data External - part of the reacTIVision project
	http://reactivision.sourceforge.net/

	Copyright (c) 2005-2009 Martin Kaltenbrunner <mkalten@iua.upf.edu>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "TuioWrapper.h"
	
TuioWrapper::TuioWrapper(int p) {

	udp_port = p;
	running = false;
}

void TuioWrapper::addOutlet(t_outlet *m,  t_outlet *r) {
	message_outlet.push_back(m);
	refresh_outlet.push_back(r);	
}

void TuioWrapper::removeOutlet(t_outlet *m,  t_outlet *r) {
	std::list<t_outlet*>::iterator m_outlet = find(message_outlet.begin(), message_outlet.end(), m);
	if (m_outlet!=message_outlet.end()) message_outlet.remove(m);

	std::list<t_outlet*>::iterator r_outlet = find(refresh_outlet.begin(), refresh_outlet.end(), r);
	if (r_outlet!=refresh_outlet.end()) refresh_outlet.remove(r);
}

bool TuioWrapper::outletCount() {
	return message_outlet.size();
}

void TuioWrapper::addTuioObject(TuioObject *tobj) {
	
	t_atom message[5];
	SETFLOAT(&message[0],(float)tobj->getSessionID());
	SETFLOAT(&message[1],(float)tobj->getSymbolID());
	SETFLOAT(&message[2],tobj->getX());
	SETFLOAT(&message[3],tobj->getY());
	SETFLOAT(&message[4],tobj->getAngle());
	
	sys_lock();
	for(std::list<t_outlet*>::iterator outlet = message_outlet.begin(); outlet!=message_outlet.end(); outlet++) {
		outlet_anything(*outlet, gensym((char*)"addObject"), 5, message);
	}
	sys_unlock();	
}

void TuioWrapper::updateTuioObject(TuioObject *tobj) {

	t_atom message[10];
	SETFLOAT(&message[0],(float)tobj->getSessionID());
	SETFLOAT(&message[1],(float)tobj->getSymbolID());
	SETFLOAT(&message[2],tobj->getX());
	SETFLOAT(&message[3],tobj->getY());
	SETFLOAT(&message[4],tobj->getAngle());
	SETFLOAT(&message[5],tobj->getXSpeed());
	SETFLOAT(&message[6],tobj->getYSpeed());
	SETFLOAT(&message[7],tobj->getRotationSpeed());
	SETFLOAT(&message[8],tobj->getMotionAccel());
	SETFLOAT(&message[9],tobj->getRotationAccel());
	
	if (sys_trylock()==0) {
		for (std::list<t_outlet*>::iterator outlet = message_outlet.begin(); outlet!=message_outlet.end(); outlet++) {
			outlet_anything(*outlet, gensym((char*)"updateObject"), 10, message);
		}
		sys_unlock();
	}
}

void TuioWrapper::removeTuioObject(TuioObject *tobj) {

	t_atom message[2];
	SETFLOAT(&message[0],(float)tobj->getSessionID());
	SETFLOAT(&message[1],(float)tobj->getSymbolID());
	sys_lock();
	for(std::list<t_outlet*>::iterator outlet = message_outlet.begin(); outlet!=message_outlet.end(); outlet++) {
		outlet_anything(*outlet, gensym((char*)"removeObject"), 2, message);
	}
	sys_unlock();
}

void TuioWrapper::addTuioCursor(TuioCursor *tcur) {

	t_atom message[4];
	SETFLOAT(&message[0],(float)tcur->getSessionID());
	SETFLOAT(&message[1],(float)tcur->getCursorID());
	SETFLOAT(&message[2],tcur->getX());
	SETFLOAT(&message[3],tcur->getY());
	
	sys_lock();
	for(std::list<t_outlet*>::iterator outlet = message_outlet.begin(); outlet!=message_outlet.end(); outlet++) {
		outlet_anything(*outlet, gensym((char*)"addCursor"), 4, message);
	}
	sys_unlock();	
}

void TuioWrapper::updateTuioCursor(TuioCursor *tcur) {

	t_atom message[7];
	SETFLOAT(&message[0],(float)tcur->getSessionID());
	SETFLOAT(&message[1],(float)tcur->getCursorID());
	SETFLOAT(&message[2],tcur->getX());
	SETFLOAT(&message[3],tcur->getY());
	SETFLOAT(&message[4],tcur->getXSpeed());
	SETFLOAT(&message[5],tcur->getYSpeed());
	SETFLOAT(&message[6],tcur->getMotionAccel());
	
	if (sys_trylock()==0) {
		for(std::list<t_outlet*>::iterator outlet = message_outlet.begin(); outlet!=message_outlet.end(); outlet++) {
			outlet_anything(*outlet, gensym((char*)"updateCursor"), 7, message);
		}
		sys_unlock();
	}
}

void TuioWrapper::removeTuioCursor(TuioCursor *tcur) {
	
	t_atom message[2];
	SETFLOAT(&message[0],(float)tcur->getSessionID());
	SETFLOAT(&message[1],(float)tcur->getCursorID());
	sys_lock();
	for(std::list<t_outlet*>::iterator outlet = message_outlet.begin(); outlet!=message_outlet.end(); outlet++) {
		outlet_anything(*outlet, gensym((char*)"removeCursor"), 2, message);
	}
	sys_unlock();
	
}

void TuioWrapper::refresh(TuioTime bundleTime) {
	
	if (sys_trylock()==0) {
		for(std::list<t_outlet*>::iterator outlet = refresh_outlet.begin(); outlet!=refresh_outlet.end(); outlet++) {
			outlet_bang(*outlet);
		}
		sys_unlock();
	}
}

void TuioWrapper::start() {

	if (!running) {
		client = new TuioClient(udp_port);
		client->addTuioListener(this);
		client->connect();
		if (client->isConnected()) running = true;
	}
}

void TuioWrapper::stop() {
	
	if (running) {
		client->removeTuioListener(this);
		client->disconnect();
		delete client;
		running = false;
	}
}



